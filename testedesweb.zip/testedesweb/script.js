const btnLogin = document.getElementById('btnLogin');
const dialog = document.getElementById('login');
const btnFechar = document.getElementById('btnFechar');

btnLogin.addEventListener('click', () => {
    dialog.showModal();
});

btnFechar.addEventListener('click', () => {
    dialog.close();
});

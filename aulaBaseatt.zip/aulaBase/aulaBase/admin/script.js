let dados = JSON.parse(localStorage.getItem('dados')) || [];

let nome = document.getElementById('nome');
let quantidade = document.getElementById('quantidade');
let preco = document.getElementById('preco');
let email = document.getElementById('email');
let editandoIndice = null;  // Variável para rastrear se estamos editando um produto

document.getElementById('formProduto').addEventListener('submit', e => {
    e.preventDefault();

    // Validação dos campos
    if (!nome.value.trim() || !quantidade.value || !preco.value.trim() || !email.value.trim()) {
        alert('Por favor, preencha todos os campos corretamente.');
        return;
    }

    // Validação do preço (somente números e ponto decimal)
    if (isNaN(preco.value) || parseFloat(preco.value) <= 0) {
        alert('Por favor, insira um preço válido.');
        return;
    }

    // Validação da quantidade (deve ser maior que zero)
    if (quantidade.value <= 0) {
        alert('A quantidade deve ser maior que zero.');
        return;
    }

    // Verificar duplicidade de nome e e-mail (se não for edição)
    if (editandoIndice === null) {
        const nomeDuplicado = dados.some(produto => produto.nome.toLowerCase() === nome.value.toLowerCase());
        const emailDuplicado = dados.some(produto => produto.email.toLowerCase() === email.value.toLowerCase());

        if (nomeDuplicado) {
            alert('Já existe um produto cadastrado com este nome.');
            return;
        }

        if (emailDuplicado) {
            alert('Já existe um produto cadastrado com este e-mail.');
            return;
        }
    } else {
        // Verificar duplicidade de nome e e-mail em modo de edição (ignorando o produto atual)
        const nomeDuplicado = dados.some((produto, index) => 
            produto.nome.toLowerCase() === nome.value.toLowerCase() && index !== editandoIndice);
        const emailDuplicado = dados.some((produto, index) => 
            produto.email.toLowerCase() === email.value.toLowerCase() && index !== editandoIndice);

        if (nomeDuplicado) {
            alert('Já existe um produto cadastrado com este nome.');
            return;
        }

        if (emailDuplicado) {
            alert('Já existe um produto cadastrado com este e-mail.');
            return;
        }
    }

    const produto = {
        nome: nome.value,
        quantidade: quantidade.value,
        preco: preco.value,
        email: email.value
    };

    if (editandoIndice === null) {
        // Se não estiver editando, adicione um novo produto
        dados.push(produto);
    } else {
        // Atualize o produto existente
        dados[editandoIndice] = produto;
        editandoIndice = null;  // Redefina o índice para a próxima inserção
    }

    localStorage.setItem('dados', JSON.stringify(dados));
    window.location.href = "./index.html";
});

function atualizarTabela() {
    const tbody = document.querySelector('#tabela tbody');
    tbody.innerHTML = ''; // Limpar o tbody antes de adicionar novas linhas

    dados.forEach((produto, chave) => {
        const linha = document.createElement('tr');
        linha.innerHTML = `
            <td>${produto.nome}</td>
            <td>${produto.quantidade}</td>
            <td>${produto.preco}</td>
            <td>${produto.email}</td>
            <td>
                <a href="#" onclick="editarProduto(${chave})">Editar</a>
                <a href="#" onclick="removerProduto(${chave})">Excluir</a>
            </td>
        `;
        tbody.appendChild(linha);
    });
}

function removerProduto(index) {
    // Removendo através da chave
    dados.splice(index, 1);
    localStorage.setItem('dados', JSON.stringify(dados));
    window.location.reload();
}

function editarProduto(index) {
    // Preenche os campos com os dados do produto selecionado para edição
    const produto = dados[index];
    nome.value = produto.nome;
    quantidade.value = produto.quantidade;
    preco.value = produto.preco;
    email.value = produto.email;

    // Armazenar o índice do produto que está sendo editado
    editandoIndice = index;
}

window.onload = atualizarTabela;
let login = sessionStorage.getItem('usuarioLogado');

if (!login) window.location.href = "../index.html";

let usuario= sessionStorage.getItem('nomeUsuario');


//essa parte nao precisa muito.
document.getElementById('logout').addEventListener('click', e => {
    e.preventDefault();

    sessionStorage.removeItem('usuarioLogado');
    sessionStorage.removeItem('nomeUsuario');
    window.location.href = "../index.html";

})